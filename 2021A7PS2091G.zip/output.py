def Print(value=None): print(value)
from engine import TetrisEngine

engine = TetrisEngine()
def pre_play(*args, **kwargs): pass
def post_play(*args, **kwargs): pass
def play(*args, **kwargs):
    pre_play(*args, **kwargs)
    engine.run(*args, **kwargs)
    post_play(*args, **kwargs)


def move_left(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 3)
    engine._move_left()
engine.move_left = move_left

def move_right(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 4)
    engine._move_right()
engine.move_right = move_right

def rotate(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 5)
    engine.rotate_CW()
engine.rotate = rotate

def speed_up(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 6)
    engine._speed_up()
engine.speed_up = speed_up

def slow_down(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 7)
    engine._slow_down()
engine.slow_down = slow_down

def pre_play(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 1)
engine.pre_play = pre_play

def post_play(*args, **kwargs):
    for c in kwargs: exec(f'{c} = {kwargs.get(c)}')
    Print(value = 2)
engine.post_play = post_play


play()


